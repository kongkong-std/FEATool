import argparse
import numpy as np

def parse_int(line):
    """从可能带注释的行中提取整数"""
    line = line.strip()
    if not line:
        return None
    first_part = line.split()[0]
    if first_part.isdigit():
        return int(first_part)
    return None


def compute_normals(coords, elements):
    """
    计算每个顶点的单位外法向量（面积加权）
    coords: [[x,y,z], ...]
    elements: [[i1,i2,i3], ...]  —— COMSOL 为 0-based
    """
    coords = np.array(coords)
    num_vertices = len(coords)

    vertex_normal_sum = np.zeros((num_vertices, 3), dtype=float)

    for elem in elements:
        i1, i2, i3 = elem[0], elem[1], elem[2]

        r1 = coords[i1]
        r2 = coords[i2]
        r3 = coords[i3]

        # 单元法向（未归一化）
        cross_vec = np.cross(r2 - r1, r3 - r1)
        area = np.linalg.norm(cross_vec) * 0.5

        if area == 0:
            continue  # 跳过退化单元

        n_elem = cross_vec / np.linalg.norm(cross_vec)

        # 面积加权累加
        vertex_normal_sum[i1] += area * n_elem
        vertex_normal_sum[i2] += area * n_elem
        vertex_normal_sum[i3] += area * n_elem

    # 归一化得到单位外法向量
    normals = np.zeros_like(vertex_normal_sum)
    for i in range(num_vertices):
        norm = np.linalg.norm(vertex_normal_sum[i])
        if norm > 0:
            normals[i] = vertex_normal_sum[i] / norm
        else:
            normals[i] = np.array([0, 0, 1])  # 极小概率情况

    return normals



def parse_mesh_file(input_file, vertex_file=None, element_file=None, normal_file=None):
    coords = []
    elements = []

    # 读取文件
    with open(input_file, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()

    # ----------------------- 解析顶点 -----------------------
    i = 0
    while i < len(lines):
        if "# Mesh vertex coordinates" in lines[i]:
            i += 1
            break
        i += 1

    while i < len(lines):
        line = lines[i].strip()
        if not line or line.startswith("#"):
            i += 1
            continue
        parts = line.split()
        if len(parts) >= 3:
            try:
                coords.append([float(parts[0]), float(parts[1]), float(parts[2])])
            except ValueError:
                pass
        else:
            break
        i += 1

    num_vertices = len(coords)
    print(f"Parsed {num_vertices} vertex coordinates.")

    # ----------------------- 解析三角形单元 -----------------------
    i = 0
    while i < len(lines):
        if lines[i].strip() == "# Type #2":
            i += 1
            while i < len(lines) and "tri" not in lines[i]:
                i += 1
            if i >= len(lines):
                raise ValueError("Cannot find 'tri' after # Type #2")

            # 顶点数
            i += 1
            while i < len(lines) and not lines[i].strip():
                i += 1
            vertices_per_element = parse_int(lines[i])
            i += 1

            # 单元数
            while i < len(lines) and not lines[i].strip():
                i += 1
            num_elements = parse_int(lines[i])
            i += 1

            print(f"Detected tri element type: vertices per element = {vertices_per_element}")
            print(f"Number of tri elements: {num_elements}")

            while i < len(lines) and not lines[i].strip().startswith("# Elements"):
                i += 1
            i += 1

            count = 0
            temp = []
            while count < num_elements and i < len(lines):
                parts = lines[i].strip().split()
                for p in parts:
                    if p.isdigit():
                        temp.append(int(p))
                        if len(temp) == vertices_per_element:
                            elements.append(temp)
                            temp = []
                            count += 1
                i += 1

            print(f"Parsed {len(elements)} tri elements.")
            break
        i += 1

    # ----------------------- 写入顶点 -----------------------
    if vertex_file:
        with open(vertex_file, 'w') as fout:
            for coord in coords:
                fout.write(" ".join(map(str, coord)) + "\n")
        print(f"Vertex coordinates written to: {vertex_file}")

    # ----------------------- 写入单元 -----------------------
    if element_file:
        with open(element_file, 'w') as fout:
            for elem in elements:
                fout.write(" ".join(map(str, elem)) + "\n")
        print(f"Tri element connectivity written to: {element_file}")

    # ----------------------- 计算单位外法 + 写入文件 -----------------------
    if normal_file:
        normals = compute_normals(coords, elements)
        with open(normal_file, 'w') as fout:
            for n in normals:
                fout.write(f"{n[0]} {n[1]} {n[2]}\n")
        print(f"Vertex normals written to: {normal_file}")

    print(f"Finished parsing mesh file: {input_file}")
    print(f"Total vertices: {len(coords)}")
    print(f"Total tri elements: {len(elements)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Parse COMSOL mesh and extract vertices, elements, and vertex normals."
    )
    parser.add_argument("input_file", help="Path to mesh file (.mphtxt)")
    parser.add_argument("--vertex_file", help="Output vertex coordinates")
    parser.add_argument("--element_file", help="Output tri element connectivity")
    parser.add_argument("--normal_file", help="Output vertex normals (nx, ny, nz)")

    args = parser.parse_args()
    parse_mesh_file(args.input_file, args.vertex_file, args.element_file, args.normal_file)


'''
用法示例：
python mesh-process.py mesh.txt --vertex_file vertices.txt --element_file elements.txt --normal_file mesh-normal.txt
'''
