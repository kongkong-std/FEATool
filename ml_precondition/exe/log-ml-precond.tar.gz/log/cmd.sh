mkdir -p cg/refine0/no-pre
mkdir -p cg/refine0/boomeramg-num1
mkdir -p cg/refine0/boomeramg-num6
mkdir -p cg/refine0/mla-rbm1
mkdir -p cg/refine0/mla-rbm2
mkdir -p cg/refine0/ilu
mkdir -p cg/refine0/jacobi
mkdir -p cg/refine0/sor

mkdir -p cg/refine3/no-pre
mkdir -p cg/refine3/boomeramg-num1
mkdir -p cg/refine3/boomeramg-num6
mkdir -p cg/refine3/mla-rbm1
mkdir -p cg/refine3/mla-rbm2
mkdir -p cg/refine3/ilu
mkdir -p cg/refine3/jacobi
mkdir -p cg/refine3/sor

mkdir -p cg/refine2/no-pre
mkdir -p cg/refine2/boomeramg-num1
mkdir -p cg/refine2/boomeramg-num6
mkdir -p cg/refine2/mla-rbm1
mkdir -p cg/refine2/mla-rbm2
mkdir -p cg/refine2/ilu
mkdir -p cg/refine2/jacobi
mkdir -p cg/refine2/sor

mkdir -p cg/refine1/no-pre
mkdir -p cg/refine1/boomeramg-num1
mkdir -p cg/refine1/boomeramg-num6
mkdir -p cg/refine1/mla-rbm1
mkdir -p cg/refine1/mla-rbm2
mkdir -p cg/refine1/ilu
mkdir -p cg/refine1/jacobi
mkdir -p cg/refine1/sor

mkdir -p fgmres/refine0/no-pre
mkdir -p fgmres/refine0/boomeramg-num1
mkdir -p fgmres/refine0/boomeramg-num6
mkdir -p fgmres/refine0/mla-rbm1
mkdir -p fgmres/refine0/mla-rbm2
mkdir -p fgmres/refine0/ilu
mkdir -p fgmres/refine0/jacobi
mkdir -p fgmres/refine0/sor

mkdir -p fgmres/refine3/no-pre
mkdir -p fgmres/refine3/boomeramg-num1
mkdir -p fgmres/refine3/boomeramg-num6
mkdir -p fgmres/refine3/mla-rbm1
mkdir -p fgmres/refine3/mla-rbm2
mkdir -p fgmres/refine3/ilu
mkdir -p fgmres/refine3/jacobi
mkdir -p fgmres/refine3/sor

mkdir -p fgmres/refine2/no-pre
mkdir -p fgmres/refine2/boomeramg-num1
mkdir -p fgmres/refine2/boomeramg-num6
mkdir -p fgmres/refine2/mla-rbm1
mkdir -p fgmres/refine2/mla-rbm2
mkdir -p fgmres/refine2/ilu
mkdir -p fgmres/refine2/jacobi
mkdir -p fgmres/refine2/sor

mkdir -p fgmres/refine1/no-pre
mkdir -p fgmres/refine1/boomeramg-num1
mkdir -p fgmres/refine1/boomeramg-num6
mkdir -p fgmres/refine1/mla-rbm1
mkdir -p fgmres/refine1/mla-rbm2
mkdir -p fgmres/refine1/ilu
mkdir -p fgmres/refine1/jacobi
mkdir -p fgmres/refine1/sor
